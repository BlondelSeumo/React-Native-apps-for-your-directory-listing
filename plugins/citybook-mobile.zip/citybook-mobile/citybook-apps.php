<?php
/*
Plugin Name: CityBook Mobile App
Plugin URI: https://citybook.cththemes.com
Description: A custom plugin for CityBook - Directory & Listing WordPress Theme
Version: 2.4.5
Author: CTHthemes
Author URI: http://themeforest.net/user/cththemes
Text Domain: citybook-mobile
Domain Path: /languages/
Copyright: ( C ) 2014 - 2019 cththemes.com . All rights reserved.
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if ( ! defined('ABSPATH') ) {
    die('Please do not load this file directly!');
}

if ( ! defined( 'CTH_MOBILE_FILE' ) ) {
    define( 'CTH_MOBILE_FILE', __FILE__ );
}
if ( ! class_exists( 'CTHMobile_Addons' ) ) {
    include_once dirname( __FILE__ ) . '/includes/class-addons.php';
}

function CTHMB_ADO() {
    return CTHMobile_Addons::getInstance();
}

CTHMB_ADO();




