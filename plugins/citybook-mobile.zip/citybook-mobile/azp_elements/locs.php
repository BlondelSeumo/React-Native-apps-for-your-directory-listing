<?php

azp_add_element(
    'app_locs',
    array(
        'name'                    => __('Locations', 'citybook-mobile'),
        'category'                => 'Mobile App',
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => false,
        'showTypographyTab'       => false,
        'showAnimationTab'        => false,
        'template_folder'         => 'apps/',
        'is_section'              => true,
        'attrs'                   => array(
            array(
                'type'       => 'text',
                'param_name' => 'title',
                'label'      => __('Title', 'citybook-mobile'),
                // 'desc'                  => '',
                'default'    => 'Explore best cities',
                'show_in_admin' => true,
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_view_all',
                'label'         => __('Show View all?', 'citybook-mobile'),
                'desc'          => '',
                'default'       => 'yes',
                'value'         => array(
                    'yes' => __('Yes', 'citybook-mobile'),
                    'no'  => __('No', 'citybook-mobile'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'viewall_text',
                'label'      => __('View all text', 'citybook-mobile'),
                // 'desc'                  => '',
                'default'    => 'View all',
            ),

            array(
                'type'          => 'select',
                'param_name'    => 'ele_layout',
                'show_in_admin' => true,
                'label'         => __('Layout', 'citybook-mobile'),
                'default'       => 'grid',
                'value'         => array(
                    'carousel'  => __('Carousel', 'citybook-mobile'),
                    'grid'      => __('Grid', 'citybook-mobile'),
                ),
            ),

            
            array(
                'type'       => 'text',
                'param_name' => 'cat_ids',
                'label'      => __('Locations IDs', 'citybook-mobile'),
                'desc'       => __('Enter Locations ids to include, separated by a comma (,). Leave empty to show all.', 'citybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'cat_ids_not',
                'label'      => __('Or Locations IDs to Exclude', 'citybook-mobile'),
                'desc'       => __( 'Enter Locations ids to include, separated by a comma (,).', 'citybook-mobile' ),
                'default'    => '',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'hide_empty',
                'show_in_admin' => true,
                'label'         => __('Hide Empty', 'citybook-mobile'),
                'desc'          => esc_html__('Hide categories  has no listings assigned to.', 'citybook-mobile'),
                'default'       => 'yes',
                'value'         => array(
                    'yes' => __('Yes', 'citybook-mobile'),
                    'no'  => __('No', 'citybook-mobile'),
                ),
            ),

        
            array(
                'type'          => 'select',
                'param_name'    => 'orderby',
                'show_in_admin' => true,
                'label'         => __('Order by', 'citybook-mobile'),
                'default'       => 'count',
                'value'         => array(

                    'name' => esc_html__('Name', 'citybook-mobile'), 
                    'slug' => esc_html__('Slug', 'citybook-mobile'), 
                    'term_group' => esc_html__('Term Group', 'citybook-mobile'), 
                    'term_id' => esc_html__('Term ID', 'citybook-mobile'), 
                    'description' => esc_html__('Description', 'citybook-mobile'),
                    'parent' => esc_html__('Parent', 'citybook-mobile'),
                    'count' => esc_html__('Term Count', 'citybook-mobile'),
                    'include' => esc_html__('For Include above', 'citybook-mobile'),
                ),
            ),
            array(
                'type'          => 'select',
                'param_name'    => 'order',
                'show_in_admin' => true,
                'label'         => __('Sort Order', 'citybook-mobile'),
                'default'       => 'DESC',
                'value'         => array(
                    'ASC'  => __('Ascending', 'citybook-mobile'),
                    'DESC' => __('Descending', 'citybook-mobile'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'number',
                'label'      => __('Numbers show', 'citybook-mobile'),
                'desc'       => __( 'Number of Categories to show (0 for all).', 'citybook-mobile' ),
                'default'    => '6',
            ),


            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_id',
            //     'label'      => __('Element ID', 'citybook-mobile'),
            //     // 'desc'                  => '',
            //     'default'    => '',
            // ),

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_class',
            //     'label'      => __('Extra Class', 'citybook-mobile'),
            //     'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'citybook-mobile'),
            //     'default'    => '',
            // ),

        ),
    )
);
