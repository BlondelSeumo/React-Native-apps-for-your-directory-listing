<?php

azp_add_element(
    'app_listings',
    array(
        'name'                    => __('Listings', 'citybook-mobile'),
        'category'                => 'Mobile App',
        'icon'                    => ESB_DIR_URL . 'assets/azp-eles-icon/cththemes-logo.png',
        'open_settings_on_create' => true,
        'showStyleTab'            => false,
        'showTypographyTab'       => false,
        'showAnimationTab'        => false,
        'template_folder'         => 'apps/',
        'is_section'              => true,
        'attrs'                   => array(
            array(
                'type'       => 'text',
                'param_name' => 'title',
                'label'      => __('Title', 'citybook-mobile'),
                // 'desc'                  => '',
                'default'    => 'Discover featured listings',
                'show_in_admin' => true,
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'show_view_all',
                'label'         => __('Show View all?', 'citybook-mobile'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'citybook-mobile'),
                    'no'  => __('No', 'citybook-mobile'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'viewall_text',
                'label'      => __('View all text', 'citybook-mobile'),
                // 'desc'                  => '',
                'default'    => 'View all',
            ),

            array(
                'type'          => 'select',
                'param_name'    => 'ele_layout',
                'show_in_admin' => true,
                'label'         => __('Layout', 'citybook-mobile'),
                'default'       => 'slider',
                'value'         => array(
                    'slider'    => __('Slider', 'citybook-mobile'),
                    'carousel'  => __('Carousel', 'citybook-mobile'),
                    'list'      => __('List', 'citybook-mobile'),
                    'grid'      => __('Grid', 'citybook-mobile'),
                ),
            ),

            

            array(
                'type'       => 'text',
                'param_name' => 'cat_ids',
                'label'      => __('Listing Categories', 'citybook-mobile'),
                'desc'       => __( "Enter listing category's ids to get listings from, separated by a comma (,).", 'citybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'loc_ids',
                'label'      => __('Listing Locations', 'citybook-mobile'),
                'desc'       => __( "Enter listing location's ids to get listings from, separated by a comma (,).", 'citybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'tag_ids',
                'label'      => __('Listing Tags', 'citybook-mobile'),
                'desc'       => __( "Enter listing tag's ids to get listings from, separated by a comma (,).", 'citybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'ids',
                'label'      => __('Enter Listing IDs', 'citybook-mobile'),
                'desc'       => __( 'Enter Post ids to show, separated by a comma (,). Leave empty to show all.', 'citybook-mobile' ),
                'default'    => '',
            ),
            array(
                'type'       => 'text',
                'param_name' => 'ids_not',
                'label'      => __('Or Post IDs to Exclude', 'citybook-mobile'),
                'desc'       => __( 'Enter post ids to exclude, separated by a comma (,). Use if the field above is empty.', 'citybook-mobile' ),
                'default'    => '',
            ),

            array(
                'type'          => 'switch',
                'param_name'    => 'featured_only',
                'show_in_admin' => true,
                'label'         => __('Show featured listings only?', 'citybook-mobile'),
                'desc'          => '',
                'default'       => 'no',
                'value'         => array(
                    'yes' => __('Yes', 'citybook-mobile'),
                    'no'  => __('No', 'citybook-mobile'),
                ),
            ),

            

            array(
                'type'          => 'select',
                'param_name'    => 'orderby',
                'show_in_admin' => true,
                'label'         => __('Order by', 'citybook-mobile'),
                'default'       => 'date',
                'value'         => array(

                    'date' => esc_html__('Date', 'citybook-mobile'), 
                    'ID' => esc_html__('ID', 'citybook-mobile'), 
                    'author' => esc_html__('Author', 'citybook-mobile'), 
                    'title' => esc_html__('Title', 'citybook-mobile'), 
                    'modified' => esc_html__('Modified', 'citybook-mobile'),
                    'rand' => esc_html__('Random', 'citybook-mobile'),
                    'comment_count' => esc_html__('Comment Count', 'citybook-mobile'),
                    'menu_order' => esc_html__('Menu Order', 'citybook-mobile'),
                    'post__in' => esc_html__('ID order given (post__in)', 'citybook-mobile'),
                    'listing_featured' => esc_html__('Listing Featured', 'citybook-mobile'),
                ),
            ),
            array(
                'type'          => 'select',
                'param_name'    => 'order',
                'show_in_admin' => true,
                'label'         => __('Sort Order', 'citybook-mobile'),
                'default'       => 'DESC',
                'value'         => array(
                    'ASC'  => __('Ascending', 'citybook-mobile'),
                    'DESC' => __('Descending', 'citybook-mobile'),
                ),
            ),

            array(
                'type'       => 'text',
                'param_name' => 'posts_per_page',
                'label'      => __('Posts to show', 'citybook-mobile'),
                'desc'       => __( 'Number of posts to show (-1 for all).', 'citybook-mobile' ),
                'default'    => '12',
            ),
            

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_id',
            //     'label'      => __('Element ID', 'citybook-mobile'),
            //     // 'desc'                  => '',
            //     'default'    => '',
            // ),

            // array(
            //     'type'       => 'text',
            //     'param_name' => 'el_class',
            //     'label'      => __('Extra Class', 'citybook-mobile'),
            //     'desc'       => __("Use this field to add a class name and then refer to it in your CSS.", 'citybook-mobile'),
            //     'default'    => '',
            // ),

        ),
    )
);


        